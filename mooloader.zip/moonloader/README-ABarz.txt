ABarz 1.9.9

В комплекте: abarz1.6.lua. Установите только одну сборку ABarz.
Скопируйте папку moonloader в папку игры.
Требуются MoonLoader, mimgui, effil, SAMP.Lua и стандартные библиотеки сборки.
Меню: /abarz. Поиск цены: /abprice название или /carprice название.
Иконки берутся из игрового arizona/items.zip при просмотре.
Отдельные PNG, индекс и библиотека abarz-webp.lua не нужны.

Для цен деталей из Arizona Market VC дополнительно подключите мост:
закройте игру и запустите moonloader/tools/Install-ArzMarketBridge.cmd.
Нужен оригинальный Arizona Market 3.57. Оригинал сохраняется.
Если мост уже подключён, повторять не нужно. В /crr выберите Vice City.
Без моста остальные функции ABarz продолжают работать.
